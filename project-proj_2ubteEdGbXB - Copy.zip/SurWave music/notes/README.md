# SurWave Music

A web-based music streaming application clone inspired by Spotify.

## Features
- **Sidebar Navigation**: Quick access to Home, Search, and Library.
- **Music Player**: Persistent bottom player with playback controls (Play, Pause, Next, Previous).
- **Responsive Layout**: Adapts to different screen sizes.
- **Dynamic Content**: Featured playlists and recently played sections.

## Tech Stack
- React 18
- TailwindCSS
- Lucide Icons (Static)

## Project Structure
- `index.html`: Main entry point and styles.
- `app.js`: Root component and state management.
- `components/`: UI components (Sidebar, Player, etc.).
- `data/`: Mock data for songs and playlists.